//
//  BottomSheetViewController.swift
//  BottomSheet
//
//  Created by Pravin Muthukumar.B on 14/11/24.
//

import UIKit

class BottomSheetViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var containerBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var contentHeightConstraint: NSLayoutConstraint!
    var tableViewHeight: CGFloat = 0
    var array = ["1","2"]
    var array1 = ["1"]
    //["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17"]
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = .red
        tableView.dataSource = self
        tableView.delegate = self
        let nib2 = UINib(nibName: "CustomTableCell", bundle: nil)
        tableView.register(nib2, forCellReuseIdentifier: "CustomTableCell")
        let nib1 = UINib(nibName: "SummaryTableViewCell", bundle: nil)
        tableView.register(nib1, forCellReuseIdentifier: "SummaryTableViewCell")
        // Do any additional setup after loading the view.
    }
    override func viewDidLayoutSubviews() {
        tableView.reloadData()
        updateTableViewHeight()
    }
    
    
    @IBAction func confirmAction(_ sender: Any) {
        let newItem = "New Item \(array.count + 1)"
        array.append(newItem)
        let indexPath = IndexPath(row: array.count - 1, section: 0)
        tableView.insertRows(at: [indexPath], with: .automatic)
        updateTableViewHeight()
        print("safeAreaInsets \(self.view.safeAreaInsets.top)")
        tableView.reloadData()
    }
    func updateTableViewHeight() {
        tableView.layoutIfNeeded()
        let totalHeight = tableView.contentSize.height
        let maxHeight = view.safeAreaLayoutGuide.layoutFrame.height - 120
        print("safeArea\( view.safeAreaLayoutGuide.layoutFrame.height )")
        if totalHeight < maxHeight {
            contentHeightConstraint.constant = totalHeight
            tableView.isScrollEnabled = false // Disable scrolling if content fits within the available space
        } else {
            contentHeightConstraint.constant = maxHeight
            tableView.isScrollEnabled = true // Enable scrolling if content exceeds the max allowable height
        }
        print("Tableheight\( contentHeightConstraint.constant )")
        DispatchQueue.main.async {
            UIView.animate(withDuration: 0.3) {
                self.view.layoutIfNeeded()
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return array.count
      }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "SummaryTableViewCell", for: indexPath) as! SummaryTableViewCell
            cell.summaryTitleLbl?.text = array[indexPath.row]
            return cell
        }else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTableCell", for: indexPath) as! CustomTableCell
            cell.headerLbl?.text = array[indexPath.row]
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return  UITableView.automaticDimension
        }else{
            return UITableView.automaticDimension
        }
        
    }
    
}
