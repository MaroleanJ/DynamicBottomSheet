//
//  SummaryTableViewCell.swift
//  BottomSheet
//
//  Created by Pravin Muthukumar.B on 14/11/24.
//

import UIKit

class SummaryTableViewCell: UITableViewCell {
    @IBOutlet weak var summaryTitleLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
