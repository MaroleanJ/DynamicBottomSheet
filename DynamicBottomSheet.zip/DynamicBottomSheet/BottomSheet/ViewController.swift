//
//  ViewController.swift
//  BottomSheet
//
//  Created by Pravin Muthukumar.B on 14/11/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func openBottomSheetAction(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let bottomSheetVC = storyboard.instantiateViewController(withIdentifier: "BottomSheetViewController") as! BottomSheetViewController
        bottomSheetVC.modalPresentationStyle = .overCurrentContext
        bottomSheetVC.modalTransitionStyle = .coverVertical
        present(bottomSheetVC, animated: true, completion: nil)
    }
    
}

